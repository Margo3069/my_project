import telebot
from telebot import types



TOKEN = ''
bot = telebot.TeleBot(TOKEN)

tasks = []
next_id = 1

class Task:
    def __init__(self, name: str):
        global next_id
        self.id = next_id
        next_id += 1
        self.name = name
        self.is_completed = False

    def complete(self):
        self.is_completed = True

    def __str__(self):
        status = "✅" if self.is_completed else "❌"
        return f"Задача №{self.id}: {self.name} {status}"


@bot.message_handler(commands=['start'])
def command_start(message):
    text = ("Привет! Я бот для списка дел.\nНапиши /help, чтобы увидеть команды.")
    bot.reply_to(message,  text)


@bot.message_handler(commands=['help'])
def command_help(message):
    text = (
        "Доступные команды:\n"
        "/start — приветствие\n"
        "/help — показать список команд\n"
        "/add <название> — добавить новую задачу\n"
        "/list — вывести список текущих задач\n"
        "/delete <номер> — удалить задачу по номеру\n"
        "/complete <номер> — отметить задачу как выполненную"
    )
    bot.reply_to(message, text) 


@bot.message_handler(commands=['add'])
def command_add(message):
    try:
        raw = message.text.strip()
        if len(raw) <= 4:
            raise ValueError("Неверный формат")
        task_name = raw[4:].strip()
        if not task_name:
            raise ValueError("Название задачи не может быть пустым")
        new_task = Task(task_name) 
        tasks.append(new_task)
        bot.reply_to(message, f"Задача добавлена:\n{new_task}")
    except Exception:
        bot.reply_to(message, "Произошла непредвиденная ошибка.")


@bot.message_handler(commands=['list'])
def command_list(message):
    if not tasks:
        bot.reply_to(message, "Список задач пуст. Добавь задачу через /add.")
        return

    response = "Твои задачи:\n\n" + "\n".join(str(t) for t in tasks)
    bot.reply_to(message, response)


@bot.message_handler(commands=['delete'])
def command_delete(message):
    try:
        arg = message.text[7:].strip()
        if not arg:
            raise ValueError("Неверный формат. Напиши: /delete <номер задачи>")
        task_id = int(arg)
        global tasks
        before_len = len(tasks)
        tasks = [t for t in tasks if t.id != task_id]
        if len(tasks) == before_len:
            raise ValueError(f"Такой задачи не существует. Номер: {task_id}")
        bot.reply_to(message, f"Задача №{task_id} удалена.")
    except Exception:
        bot.reply_to(message, "Произошла непредвиденная ошибка при удалении.")



@bot.message_handler(commands=['complete'])
def command_complete(message):
    try:
        arg = message.text[8:].strip()
        if not arg:
            raise ValueError("Неверный формат. Напиши: /complete <номер задачи>")
        task_id = int(arg)
        for t in tasks:
            if t.id == task_id:
                t.complete()
                bot.reply_to(message, f"Отмечено как выполненное:\n{t}")
                return
        raise ValueError(f"Такой задачи не существует. Номер: {task_id}")
    except Exception:
        bot.reply_to(message, "Произошла непредвиденная ошибка при отметке задачи.")


@bot.message_handler(func=lambda _: True)
def handle_unknown(message):
    bot.reply_to(message, "Я понимаю только команды. Напиши /help, чтобы узнать, какие есть.")




if __name__ == '__main__':
    print('Бот запущен...')
    bot.polling(none_stop=True)